﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KapacitasSzamolo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSzamol_Click(object sender, RoutedEventArgs e)
        {
            int eredmeny = 0;
            int kapacitErtek = Convert.ToInt16(txtkapacit.Text);
            ComboBoxItem ComboItem1 = (ComboBoxItem)cbNagysag.SelectedItem;
            string kapacitFajta = ComboItem1.Name;

            if (kapacitFajta.Contains("GB"))
            {
                kapacitErtek = kapacitErtek * 1000;
            }
            else if (kapacitFajta.Contains("TB"))
            {
                kapacitErtek = kapacitErtek * 1000000;
            }




            int sebessegErtek = Convert.ToInt16(slikapacit.Value);
            ComboBoxItem ComboItem2 = (ComboBoxItem)cbSebesseg.SelectedItem;
            string sebessegFajta = ComboItem2.Name;

            if (sebessegFajta.Contains("GBps"))
            {
                sebessegErtek = sebessegErtek * 1000;
            }
            else if (sebessegFajta.Contains("KBps"))
            {
                sebessegErtek = sebessegErtek / 1000;
            }
            else if (sebessegFajta.Contains("Mbps"))
            {
                sebessegErtek = sebessegErtek / 8;
            }

            eredmeny = kapacitErtek / sebessegErtek;

            lbEredmeny.Content = $"{eredmeny} sec";
        }
    }
}
